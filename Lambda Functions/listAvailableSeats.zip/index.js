const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = (name, date) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE (name=? AND date=? AND isActive=?)", [name, date, true], (error, rows) => {
                if (error) { return reject(error); }
                console.log(rows)
                if ((rows) && (rows.length == 1)) {
                    return resolve(true); 
                } else {
                    return resolve(false);
                }
            });
        });
  }

  let GetSid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].sid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetSeats = (sid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM seats WHERE sid=?", [sid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length > 0)) {
                return resolve(rows);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let response = undefined
  const exists = await ValidateExists(event.name, event.date);

  if (exists) {
      
      let sort = (seats) => {
            var totA = 0;
            for(let i = 0; i < seats.length; i++) {
                if(seats[i].isAvailable == true) {
                    totA++
                }
            }
            var result = new Array(totA)
            var ptr = 0;
            for(let i = 0; i < seats.length; i++) {
                if(seats[i].isAvailable == true) {
                    result[ptr] = seats[i]
                    ptr++
                }
            }
            return result
        }
    
      const ShowID = await GetSid(event.name, event.date)
      if (ShowID != -1) {
        let add_result = await GetSeats(ShowID);
        if(add_result) {
            let AvailableSeats = sort(add_result)
            if(AvailableSeats.length > 0) {
                response = {
                    statusCode: 200,
            
                    success: AvailableSeats
                } 
            }if(AvailableSeats.length == 0) {
                response = {
                    statusCode: 400,
            
                    success: "No Available Seats"
                }
            }
        } else {
            response = {
                statusCode: 400,
        
                success: "No Seats Retreived"
            }  
        }
    } else {
        response = {
            statusCode: 400,
            
            success: "show ID could not be retrieved"
          };
    }
  } else {
      response = {
        statusCode: 400,
        
        success: "show does not exist or is inactive"
      };
  }

  pool.end();   // done with DB
  return response;
};

