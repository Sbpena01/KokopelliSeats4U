const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=? AND isActive=?)", [name, date, true], (error, rows) => {
            if (error) { return reject(error); }
            console.log(rows)
            if ((rows) && (rows.length == 1)) {
                return resolve(true); 
            } else {
                return resolve(false);
            }
        });
    });
}

let GetSid = (name, date) => {
return new Promise((resolve, reject) => {
    pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
        if (error) { return reject(error); }
        if ((rows) && (rows.length == 1)) {
            return resolve(rows[0].sid);
        } else {
            return resolve(-1);
        }
    });
});
}

  let GetVid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].vid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetRow = (vid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM venues WHERE vid=?", [vid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].rows);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetSeats = (sid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM seats WHERE sid=?", [sid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length > 0)) {
                return resolve(rows);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let response = undefined
  const exists = await ValidateExists(event.name, event.date);

  if (exists) {
      
      let sort = (seats) => {
            var totA = 0;
            for(let i = 0; i < seats.length; i++) {
                if(seats[i].isAvailable == true) {
                    totA++
                }
            }
            var result = new Array(totA)
            var ptr = 0;
            for(let i = 0; i < seats.length; i++) {
                if(seats[i].isAvailable == true) {
                    result[ptr] = seats[i]
                    ptr++
                }
            }
            return result
        }

        let sortby = (showSeats, param, row) => {
            var totA = showSeats.length;
            var result = new Array(totA)
            if(param == 0) { // Sort by Price, (not problem, team not required to work with blocks)
                result = showSeats
                return result
            } else if(param == 1) { // Sort by section
                var ptr = 0;
                for(let i = 0; i < 3; i++) {
                    var sec = "L"
                    if(i == 1) {
                        sec = "C"
                    } else if(i == 2) {
                        sec = "R"
                    }
                    for(let j = 0; j < showSeats.length; j++) {
                        if(showSeats[j].secName == sec) {
                            result[ptr] = showSeats[j]
                            ptr++
                        }
                    }
                }
                return result
            } else if(param == 2) { // Row
                var ptr = 0;
                const OFFSET = 65;
                for(let i = 0; i < row; i++){
                    let rowChar = String.fromCharCode(i + 65)
                    for(let j = 0; j < showSeats.length; j++) {
                        if(showSeats[j].row == rowChar) {
                            result[ptr] = showSeats[j]
                            ptr++
                        }
                    }
                }
                return result
            } else {
                return false
            }
        }
    
      const ShowID = await GetSid(event.name, event.date)
      const VID = await GetVid(event.name, event.date)
      const ROW = await GetRow(VID)
      if ((ShowID != -1) && (ROW != -1)) {
        let add_result = await GetSeats(ShowID);
        if(add_result) {
            let AvailableSeats = sort(add_result)
            if(AvailableSeats.length > 0) {
                let SortedSeatsBy = sortby(AvailableSeats, event.param, ROW)
                if(SortedSeatsBy != false) {
                    response = {
                        statusCode: 200,
                
                        success: SortedSeatsBy
                    } 
                } else {
                    response = {
                        statusCode: 400,
                
                        success: "Error invalid Sort Parameter"
                    }
                }
            }else {
                response = {
                    statusCode: 400,
            
                    success: "No Available Seats"
                }
            }
        } else {
            response = {
                statusCode: 400,
        
                success: "No Seats Retreived"
            }  
        }
    } else {
        response = {
            statusCode: 400,
            
            success: "show ID could not be retrieved"
          };
    }
  } else {
      response = {
        statusCode: 400,
        
        success: "show does not exist or is inactive"
      };
  }

  pool.end();   // done with DB
  return response;
};

