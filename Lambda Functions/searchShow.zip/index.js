const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {

    // get credentials from the db_access layer (loaded separately via AWS console)
    var pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database
    });

    let response = undefined
    let activeShowList = undefined
    //const can_list = await ValidateExists();

    //function takes in the users input sentence and compares it with all of the active shows names
    //if ther is a common word it returns true
    let commonWords = (userInput, databaseWords) => {
        const input = userInput.toLowerCase().split(' ');
        const listShows = databaseWords.toLowerCase().split(' ');
        console.log(input);
        console.log(input.length);
        console.log(listShows);
        console.log(listShows.length);
        let foundWord = [];
        for (let i = 0; i < input.length; i++) {
            for (let y = 0; y < listShows.length; y++) {
                if (input[i] == listShows[y]) {
                    foundWord.push(listShows[y]);
                    return true;
                }
            }

        }
        return false;
    }


    let listShows = (name) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE isActive=1", (error, rows) => {
                if (error) { return reject(error); }
                if (rows) {
                    const activeShows = []
                    for (let i = 0; i < rows.length; i++) {
                        activeShows.push(rows[i].name);
                    }
                    //return resolve(rows[0].name); // Returning the list of shows inside the vid
                    return resolve(activeShows);
                } else {
                    return resolve(0); // Returning an empty array if no active shows are found
                }
            });
        });
    }

    let gettingShows = await getShows(existingVid)
    console.log("gettingShows", await gettingShows);
    const foundCommonShow = []
    for (let s of gettingShows) {
        console.log("trying " + s)
        if (commonWords(event.name, s)) {
            foundCommonShow.push(s);
        }
    }


    if (foundCommonShow) {
        response = {
            statusCode: 200,

            success: foundCommonShow
        }
    } else {
        response = {
            statusCode: 400,

            success: false
        };
    }

    pool.end();   // done with DB
    return response;
};

