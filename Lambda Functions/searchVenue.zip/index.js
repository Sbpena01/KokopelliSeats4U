const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {

    // get credentials from the db_access layer (loaded separately via AWS console)
    var pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database
    });

    let response = undefined
    let activeShowList = undefined
    //const can_list = await ValidateExists();

    //function takes in the users input sentence and compares it with all of the active shows names
    //if ther is a common word it returns true
    let commonWords = (userInput, databaseWords) => {
        const input = userInput.toLowerCase().split(' ');
        const listShows = databaseWords.toLowerCase().split(' ');
       // console.log(input);
       // console.log(input.length);
    //    console.log(listShows);
     //   console.log(listShows.length);
        let foundWord = [];
        for (let i = 0; i < input.length; i++) {
            for (let y = 0; y < listShows.length; y++) {
                if (input[i] == listShows[y]) {
                    foundWord.push(listShows[y]);
                    return true;
                }
            }

        }
        return false;
    }
    
      
        let listVenues = () => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM venues", (error, rows) => {
                if (error) { return reject(error); }
                if (rows) {
                    const venuesL = []
                    for (let i = 0; i < rows.length; i++) {
                        venuesL.push(rows[i]);

                    }
                    //return resolve(rows[0].name); // Returning the list of shows inside the vid
                   // console.log("pushing Venuew", venuesL);

                    return resolve(venuesL);
                } else {
                    return resolve(0); // Returning an empty array if no active shows are found
                }
            });
        });
    }

    
    let gettingVenuesCommon = await listVenues()
    console.log("gettingVenues", await gettingVenuesCommon);
    const foundCommonVenue = []
    for (let v of gettingVenuesCommon) {
        console.log("checking Venue " + v.name)
        if (commonWords(event.name, v.name)) {
            console.log("found common venue VID!!! " + v.vid)
            foundCommonVenue.push(v.vid);
        }
    }
    
    console.log("VENUE IDDDDDDD " + foundCommonVenue)
    
    
    
      let findShowsInVenue = (vid) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE vid AND isActive", [vid], (error, rows) => {
                if (error) { return reject(error); }
                if (rows) {
                    const showsInVenue = []
                    for (let i = 0; i < rows.length; i++) {
                        if(rows[i].vid == vid){
                            showsInVenue.push(rows[i]);
                        }

                    }
                    //return resolve(rows[0].name); // Returning the list of shows inside the vid
                   // console.log("pushing Venuew", venuesL);

                    return resolve(showsInVenue);
                } else {
                    return resolve(0); // Returning an empty array if no active shows are found
                }
            });
        });
    }
    
    
    
    let gettingShowsInVenue = await findShowsInVenue(foundCommonVenue)
    console.log("getting shows", await gettingShowsInVenue);



    if (gettingShowsInVenue) {
        response = {
            statusCode: 200,

            success: gettingShowsInVenue
        }
    } else {
        response = {
            statusCode: 400,

            success: false
        };
    }

    pool.end();   // done with DB
    return response;
};

