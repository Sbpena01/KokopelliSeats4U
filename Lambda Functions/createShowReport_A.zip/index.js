const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = (name) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE name=?", [name], (error, rows) => {
                if (error) { return reject(error); }
                console.log(rows)
                if ((rows) && (rows.length == 1) && (rows[0].isActive == true)) {
                    return resolve(true); 
                } else {
                    return resolve(false);
                }
            });
        });
  }

  let GetVid = (name) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM venues WHERE name=?", [name], (error, rows) => {
            if (error) { return reject(error); }
            console.log(rows)
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].vid); 
            } else {
                return resolve(-1);
            }
        });
    });
}

let GetSections = () => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM sections", [], (error, rows) => {
            if (error) { return reject(error); }
            console.log(rows)
            if ((rows) && (rows.length != 0)) {
                return resolve(rows); 
            } else {
                return resolve(false);
            }
        });
    });
}

  let GetAllSids = (vid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE vid=?", [vid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length >= 0)) {
                return resolve(rows);
            } else {
                return resolve(false);
            }
        });
    });
  }

  let GetSeats = () => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM seats", [], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length > 0)) {
                return resolve(rows);
            } else {
                return resolve(false);
            }
        });
    });
  }

  let response = undefined
  //const exists = await ValidateExists(event.name);

  if (true) {
      
      let totalseat = (seats, sid) => {
        var sum = 0;
        for(let i = 0; i < seats.length; i++) {
            if(seats[i].sid == sid) {
                sum++ 
            }
        }
        return sum
      }

      let openseat = (seats, sid) => {
        var sum = 0;
        for(let i = 0; i < seats.length; i++) {
            if(seats[i].isAvailable && seats[i].sid == sid) {
                sum++ 
            }
        }
        return sum
      }

      let inactiveTotal = (vid, sections) => {
        var sum = 0;
        for(let i = 0; i < sections.length; i++) {
            if(sections[i].vid == vid) {
                var addTo = sections[i].numRows * sections[i].numColm
                sum = sum + addTo
            }
        }
        return sum
      }

      let showReport = (shows, seats, sections) => {
            //var totA = 0;
            //for(let i = 0; i < shows.length; i++) {
            //    if(shows[i].isActive == true) {
            //        totA++
            //    }
            //}
            var result = new Array(shows.length)
            var ptr = 0;
            for(let i = 0; i < shows.length; i++) {
                if(shows[i].isActive == true) {
                    const curSID = shows[i].sid
                    const open = openseat(seats, curSID)
                    const total = totalseat(seats, curSID)
                    const diff = total - open
                    //result[ptr].name = shows[i].name
                    //result[ptr].active = true
                    //result[ptr].openSeats = openseat(seats, curSID)
                    //result[ptr].totalSeats = totalseat(seats, curSID)
                    //result[ptr].revenue = (shows[i].price * diff)
                    
                    const report = {
                        name: shows[i].name,
                        date: shows[i].date,
                        active: true,
                        openSeats: openseat(seats, curSID),
                        totalSeats: totalseat(seats, curSID),
                        revenue: (shows[i].initialPrice * diff)
                    }
                    result[ptr] = report
                    ptr++
                } else {
                    const curSID = shows[i].sid
                    const total = inactiveTotal(shows[i].vid, sections)
                    //result[ptr].name = shows[i].name
                    //result[ptr].active = false
                    //result[ptr].openSeats = inactiveTotal(shows[i].vid, sections)
                    //result[ptr].totalSeats = result[ptr].openSeats
                    //result[ptr].revenue = 0
                    
                    const report = {
                        name: shows[i].name,
                        date: shows[i].date,
                        active: false,
                        openSeats: total,
                        totalSeats: total,
                        revenue: 0
                    }
                    result[ptr] = report
                    ptr++
                }
            }
            return result
        }
    
      let result = undefined
      const VID = await GetVid(event.name)
      if(VID != -1) {
      const SIDS = await GetAllSids(VID)
      if (SIDS) {
        const SECTS = await GetSections()
        if(SECTS) {
            const SEATS = await GetSeats()
            if(SEATS) {
              result = showReport(SIDS, SEATS, SECTS)
              response = {
                statusCode: 200,
                
                success: result
              };
            } else {
                response = {
                    statusCode: 400,
                    
                    success: "Error pulling from seats"
                  };
            }
        } else {
            response = {
                statusCode: 400,
                
                success: "Error pulling from sections"
              };
        }
      } else {
        response = {
            statusCode: 400,
            
            success: "Error pulling from shows"
          };
      }
    } else {
        response = {
            statusCode: 400,
            
            success: "No Venue id could be retrieved"
          };
    }
  } else {
      response = {
        statusCode: 400,
        
        success: "show does not exist or is inactive"
      };
  }

  pool.end();   // done with DB
  return response;
};

