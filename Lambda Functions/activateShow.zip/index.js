const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = (name, date) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE (name=? AND date=? AND isActive=?)", [name, date, false], (error, rows) => {
                if (error) { return reject(error); }
                console.log(rows)
                if ((rows) && (rows.length == 1)) {
                    return resolve(true); 
                } else {
                    return resolve(false);
                }
            });
        });
  }
  
  let RetreiveSections = (vid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM sections WHERE vid=?", [vid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 3)) {
                return resolve(rows);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetSid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].sid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetVid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].vid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  
  let response = undefined
  const exists = await ValidateExists(event.name, event.date);

  if (exists) {
      let ActivateShow = (name, date) => {
        return new Promise((resolve, reject) => {
            pool.query("UPDATE shows SET isActive = true WHERE (name=? AND date=?);", [name, date], (error, rows) => {
                if (error) { return reject(error); }
                if ((rows) && (rows.affectedRows == 1)) {
                    return resolve(true);
                } else {
                    return resolve(false);
                }
            });
        });
      }
      let GenerateSeat = (row, column, secName, section, show) => {
        return new Promise((resolve, reject) => {
            let rowChar = String.fromCharCode(row + 65)
            pool.query("INSERT into seats(`row`, col, secName, isAvailable, secid, sid) VALUES(?,?,?,?,?,?);", [rowChar, column, secName, true, section, show], (error, rows) => {
                if (error) { return reject(error); }
                if ((rows) && (rows.affectedRows == 1)) {
                    return resolve(true);
                } else {
                    return resolve(false);
                }
            });
        });
      }
      let add_result = await ActivateShow(event.name, event.date);
      if(add_result) {
        const VenueID = await GetVid(event.name, event.date)
        const ShowID = await GetSid(event.name, event.date)
        if((VenueID != -1 ) && (ShowID != -1)) {
            let sections = await RetreiveSections(VenueID)
            for(let i = 0; i < sections.length; i++) { // section
                for(let j = 0; j < sections[i].numRows; j++) { // row
                    for(let k = 0; k < sections[i].numColm; k++) { // column
                        let currentSeat = await GenerateSeat(j, k+1, sections[i].name, sections[i].secid, ShowID)
                    }
                }
            }
        } else {
            add_result = false;
        }
      }
      response = {
        statusCode: 200,
        
        success: add_result
      }
  } else {
      response = {
        statusCode: 400,
        
        success: "inactive show with this name and time does not e"
      };
  }

  pool.end();   // done with DB
  return response;
};

