const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = (name, date) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
                if (error) { return reject(error); }
                console.log(rows)
                if ((rows) && (rows.length == 1) && (rows[0].isActive == true)) {
                    return resolve(true); 
                } else {
                    return resolve(false);
                }
            });
        });
  }

  let GetSid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].sid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let GetSeats = (sid) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM seats WHERE sid=?", [sid], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length > 0)) {
                return resolve(rows);
            } else {
                return resolve(-1);
            }
        });
    });
  }

  let response = undefined
  const exists = await ValidateExists(event.name, event.date);

  if (exists) {
      let buySeat = (stid) => {
        return new Promise((resolve, reject) => {
            pool.query("UPDATE seats SET isAvailable = false WHERE (stid=? AND isAvailable = true);", [stid], (error, rows) => {
                if (error) { return reject(error); }
                if ((rows) && (rows.affectedRows == 1)) {
                    return resolve(true);
                } else {
                    return resolve(false);
                }
            });
        });
      }
      
      let getStids = (event_list, seat_list) => {
        var stids = new Array(event_list.length);
        for(let i = 0; i < event_list.length; i++) {
            let curEvent = event_list[i]
            for(let j = 0; j < seat_list.length; j++) {
                let curSeat = seat_list[j]
                if((curEvent.row == curSeat.row) && (curEvent.col == curSeat.col) && (curEvent.secName == curSeat.secName)) {
                    stids[i] = curSeat
                }
            }
            if(stids[i] == null || stids[i].isAvailable == false) {
                return false
            }
        }
        
        return stids
      }
      
      let avCheck = (seats) => {
            for(let i = 0; i < seats.length; i++) {
                if(seats.isAvailable == 0) {
                    return false
                }
            }
            return true
        }
    
      let isPast = (date) => { // ---------(TODO): GET the Date Method to Work)----------
      const now = new Date()
      const estnow = new Date(now.toLocaleString("en-US", {timeZone: "America/New_York"}))
      var then = new Date(date)
      if(then.getTime() < estnow.getTime()) {
          return false
      } else {
          return true
      }
  } // ----------------------------------------------------------------------------------
    
      let check = event.selected // -- // TEST
      const ShowID = await GetSid(event.name, event.date)
      if (ShowID != -1) {
          let timeCheck = await isPast(event.date)
          if(timeCheck == true) {
        let add_result = await GetSeats(ShowID);
        if(add_result) {
          let MySeats = await getStids(event.selected, add_result)
           if(MySeats) {
            let check = avCheck(add_result)
            if(check == true) {
            for(let i = 0; i < MySeats.length; i++) {
                 let bookseat = await buySeat(MySeats[i].stid)
             }
             response = {
                 statusCode: 200,
         
                 success: event.selected
            }
           } else {
               response = {
                 statusCode: 400,
         
                 success: "At least one seat not available"
                }
           }
            }else {
             response = {
                 statusCode: 400,
         
                 success: "At least one seat not found or available"
            }
           }
        } else {
            response = {
                statusCode: 400,
        
                success: "No Seats Retreived"
            }  
        }
          } else {
             response = {
                statusCode: 400,
        
                success: "Show has occured"
            }   
          }
    } else {
        response = {
            statusCode: 400,
            
            success: "show ID could not be retrieved"
          };
    }
  } else {
      response = {
        statusCode: 400,
        
        success: "show does not exist or is inactive"
      };
  }

  pool.end();   // done with DB
  return response;
};

