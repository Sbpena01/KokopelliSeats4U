const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let response = undefined
  let activeShowList = undefined
  //const can_list = await ValidateExists();

  const can_list = true;
  if (can_list) {
      let ListActiveShows = (vid) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM shows", (error,rows) => {
                if (error) { return reject(error); }
                if (rows && rows.length > 0) {
                    const showList = rows.map(row => ({
                      vid: row.vid,
                      name: row.name,
                      date: row.date,
                      price: row.initialPrice
                    }));
                    // const activeShows1 = rows.map(row => ({
                    //     name: row.name
                    // }));
                    
                    return resolve(showList); // Returning the list of venues
                } else {
                    return resolve([]); // Returning an empty array if no active shows are found
                }
            });
        });
    }
      //let list_result = await CreateVenue(event.name, event.rows)
      let list_result = await ListActiveShows(1)
      response = {
        statusCode: 200,
        
        success: list_result
      }
  } else {
      response = {
        statusCode: 400,
        
        success: false
      };
  }

  pool.end();   // done with DB
  return response;
};

