const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {

  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
    host: db_access.config.host,
    user: db_access.config.user,
    password: db_access.config.password,
    database: db_access.config.database
  });

  //must check if there is an active show
  //must delete anything inside of the venue 

  //checks if the venue already exists 
  let ValidateExists = (name, date) => {
    return new Promise((resolve, reject) => {
      pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
        if (error) {
          return reject(error);
        }
       return resolve(true);
      });
    });
  }
  
  let response = undefined

  const can_delete = await ValidateExists(event.name);


//if the venue exist then it can be delete
//will deal with ACTIVE SHOW LATER
if (can_delete) {
  let GetSid = (name, date) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM shows WHERE (name=? AND date=?)", [name, date], (error, rows) => {
            if (error) { return reject(error); }
            if ((rows) && (rows.length == 1)) {
                return resolve(rows[0].sid);
            } else {
                return resolve(-1);
            }
        });
    });
  }

    let DeleteShow = (name, date) => {
      return new Promise((resolve, reject) => {
        pool.query("DELETE FROM shows WHERE name=? AND date=?", [name, date], (error, rows) => {
          if (error) {
            return reject(error);
          }
          if ((rows) && (rows.affectedRows == 1)) {
            return resolve(true);
          } else {
            return resolve(false);
          }
        });
      });
    }

    let WhipeSeats = (sid) => {
      return new Promise((resolve, reject) => {
        pool.query("DELETE FROM seats WHERE sid=?", [sid], (error, rows) => {
          if (error) {
            return reject(error);
          }
          if ((rows) && (rows.affectedRows > 0)) {
            return resolve(true);
          } else {
            return resolve(false);
          }
        });
      });
    }
    
    const ShowID = await GetSid(event.name, event.date)
    let result = await DeleteShow(event.name, event.date)
    if (result) {
      let purge = await WhipeSeats(ShowID)
    }

    response = {
        statusCode: 200,

        body: result
      }

  } 
  
  else {
    response = {
      statusCode: 400,

      success: false
    };
  }
  
  pool.end();   // disconnect from database to avoid "too many connections" problem that can occur
  return response;
};
