const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });
  
  let ValidateExists = () => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM venues WHERE name=?", [], (error) => {
                if (error) { return reject(error); }
                // if ((rows) && (rows.length == 1)) {
                //     return resolve(true); 
                // } else {
                //     return resolve(false);
                // }
                return resolve(true);
            });
        });
  }
  
  let response = undefined
  let venueList = undefined
  //const can_list = await ValidateExists();

  const can_list = true;
  if (can_list) {
      let ListVenues = () => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT vid, name FROM venues", (error,rows) => {
                if (error) { return reject(error); }
                if (rows && rows.length > 0) {
                    // Processing the rows to extract the list of venues
                    const venuesList = rows.map(row => ({
                        vid: row.vid,
                        name: row.name
                    }));
                    
                    return resolve(venuesList); // Returning the list of venues
                } else {
                    return resolve([]); // Returning an empty array if no venues found
                }
                return venues;
            });
        });
      }

      let GetVid = (name) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT vid FROM venues WHERE venues.name=VALUES(?)", [name], (error, rows) => {
                if (error) { return reject(error); }
                if ((rows) && (rows.affectedRows == 1)) {
                    return resolve(true);
                } else {
                    return resolve(false);
                }
            });
        });
      }

      let MakeSection = (vid, columns, position, seats) => {
        return new Promise((resolve, reject) => {
          pool.query("INSERT into sections(numSeats,name,numColm,vid) VALUES(?,?,?,?);", [seats,position,columns,vid], (error, rows) => {
              if (error) { return reject(error); }
              if ((rows) && (rows.affectedRows == 1)) {
                  return resolve(true);
              } else {
                  return resolve(false);
              }
          });
      });
      }

      //let list_result = await CreateVenue(event.name, event.rows)
      let list_result = await ListVenues()
      response = {
        statusCode: 200,
        
        success: list_result
      }
  } else {
      response = {
        statusCode: 400,
        
        success: false
      };
  }

  pool.end();   // done with DB
  return response;
};

